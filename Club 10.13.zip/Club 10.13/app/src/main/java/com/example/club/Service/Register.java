package com.example.club.Service;

public interface Register {
    public String registerUser();
    public String registerClub();
}
