package com.example.club.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1; // Database Version
    private static final String DATABASE_NAME = "ClubSystem.db"; // Database Name

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String Create_User_Table = "create table User(username TEXT NOT NULL, password TEXT NOT NULL, emailAddress TEXT NOT NULL" +
                ", year INTEGER, type INTEGER NOT NULL, gender TEXT, PRIMARY KEY(username))";
        String Insert_User_Table = "insert into User(username,password,emailAddress,year,type,gender) values(?,?,?,?,?,?)";

        db.execSQL(Create_User_Table);
        db.execSQL(Insert_User_Table, new Object[]{"Yuqi.Guo17","1234","Yuqi.Guo17@studentt.xjtlu.edu.cn",4,3,"male"});

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
