package com.example.club.Communication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.club.R;
import com.example.club.Service.LogInImplement;

import java.util.ArrayList;
import java.util.List;


public class registerClub extends AppCompatActivity {
    private TextView registerUser;
    private TextView register;

    private EditText username;
    private EditText password;
    private EditText confirmPassword;
    protected ImageButton registerReturn;
    private boolean mbDisplayFlg = false;
    private EditText type;
    private EditText emailAddress;
    private EditText verificationCode;
    private Button send;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_club);
        username = findViewById(R.id.et_club_user);
        type = findViewById(R.id.et_club_type);
        password = findViewById(R.id.et_club_pwd);
        confirmPassword = findViewById(R.id.et_club_confirm_pwd);
        send = findViewById(R.id.bt_send);
        emailAddress = findViewById(R.id.et_club_mail);
        verificationCode=findViewById(R.id.et_code);


        registerUser = findViewById(R.id.registerUser1);
        registerUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(registerClub.this, registerUser.class);
                startActivity(intent);
                registerClub.this.finish();
            }
        });

        register = findViewById(R.id.register1);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String vCode = verificationCode.getText().toString().trim();
                if (TextUtils.isEmpty(vCode)) {
                    Toast.makeText(registerClub.this, "Input empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(verificationCode.getText().toString().trim().equals("123")){
                    Intent intent = new Intent(registerClub.this, Homepage.class);
                    startActivity(intent);
                    registerClub.this.finish();
                }else {
                    Toast.makeText(registerClub.this, "Incorrect verification code", Toast.LENGTH_SHORT).show();
                }


            }
        });

        // return to lohin
        registerReturn = findViewById(R.id.ib_return);
        registerReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(registerClub.this, LogIn.class);
                startActivity(intent);
                registerClub.this.finish();

            }
        });



        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String uName = username.getText().toString().trim();
                String uType = type.getText().toString().trim();
                String uPassword = password.getText().toString().trim();
                String cPassword = confirmPassword.getText().toString().trim();
                String uEmail = emailAddress.getText().toString().trim();

                if (TextUtils.isEmpty(uName) || TextUtils.isEmpty(uPassword) || TextUtils.isEmpty(uType) || TextUtils.isEmpty(cPassword) || TextUtils.isEmpty(uEmail)) {
                    Toast.makeText(registerClub.this, "Input empty", Toast.LENGTH_SHORT).show();
                } else if (uPassword.equals(cPassword) == false) {
                    Toast.makeText(registerClub.this, "Incorrect password", Toast.LENGTH_SHORT).show();
                    return;
                } else {

                }

                //hide password
                if (!mbDisplayFlg) {
                    // display password text, for example "123456"
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    // hide password, display "."
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                mbDisplayFlg = !mbDisplayFlg;
                password.postInvalidate();


            }


        });



        List<String> list = new ArrayList<String>();
        list.add("Functional Organizations");
        list.add("Academic Clubs");
        list.add("Community Service Clubs");
        list.add("Recreational Clubs");
        list.add("Art Organizations & Clubs");
        list.add("Recreational Clubs");
        list.add("Sports Clubs");
        list.add("Varsity");
        list.add("other");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        Spinner sp = (Spinner) findViewById(R.id.Spinner02);
        sp.setAdapter(adapter);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            // parent： 为控件Spinner view：显示文字的TextView position：下拉选项的位置从0开始
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView tvResult = (TextView) findViewById(R.id.et_club_type);
//获取Spinner控件的适配器
                ArrayAdapter<String> adapter = (ArrayAdapter<String>) parent.getAdapter();
                tvResult.setText(adapter.getItem(position));
            }
            //没有选中时的处理
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


    }

/*    //判断输入的验证码是否正确
    private void judgeVerificationCode() {
        if(Integer.parseInt( verificationCode.getText().toString())==receivedVerificationCode){ //验证码和输入一致
            Toast.makeText(registerClub.this,"验证成功",Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(registerClub.this, "验证失败", Toast.LENGTH_LONG).show();
        }

        String uEmail = emailAddress.getText().toString().trim();
        String vCode = verificationCode.getText().toString().trim();
        if(TextUtils.isEmpty(uEmail) || TextUtils.isEmpty(vCode)){
            Toast.makeText(registerClub.this,"Input empty",Toast.LENGTH_SHORT).show();
        }else{
            Intent intent=new Intent(registerClub.this, Homepage.class);
            startActivity(intent);
            registerClub.this.finish();
        }

    }*/


}
