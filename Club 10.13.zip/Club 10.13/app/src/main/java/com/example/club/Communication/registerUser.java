package com.example.club.Communication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.club.R;
import com.example.club.Service.LogInImplement;

import java.util.ArrayList;
import java.util.List;

public class registerUser extends AppCompatActivity {
    private TextView registerClub;
    private TextView register;

    private EditText username;
    private EditText password;
    private EditText confirmPassword;
    private ImageButton registerReturn;
    private boolean mbDisplayFlg = false;


    private String gender;
    private TextView year;



    @SuppressLint("CommitPrefEdits")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);



        registerClub = findViewById(R.id.registerClub2);
        registerClub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(registerUser.this, registerClub.class);
                startActivity(intent);
                registerUser.this.finish();

            }
        });

       // return to lohin
        registerReturn = findViewById(R.id.ib_return);
        registerReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(registerUser.this, LogIn.class);
                startActivity(intent);
                registerUser.this.finish();

            }
        });


        username = findViewById(R.id.et_register_user);
        password = findViewById(R.id.et_register_pwd);
        register = findViewById(R.id.register2);
        confirmPassword=findViewById(R.id.et_register_confirm_pwd);
        year=findViewById(R.id.tv_year);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    String uName = username.getText().toString().trim();
                    String uPassword = password.getText().toString().trim();
                    String cPassword = confirmPassword.getText().toString().trim();

                if(TextUtils.isEmpty(uName) || TextUtils.isEmpty(uPassword)|| TextUtils.isEmpty(cPassword)){
                    Toast.makeText(registerUser.this,"Input empty",Toast.LENGTH_SHORT).show();


                } else if (uPassword.equals(cPassword)==false) {
                    Toast.makeText(registerUser.this, "Incorrect password", Toast.LENGTH_SHORT).show();
                }else {
                    Intent intent=new Intent(registerUser.this, Homepage.class);
                    startActivity(intent);
                    registerUser.this.finish();
                }






                // gender
                final RadioGroup radioGroup = findViewById(R.id.radio_gender);
                radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, int checkedId) {
                        RadioButton rb = (RadioButton)findViewById(radioGroup.getCheckedRadioButtonId());
                        gender = rb.getText().toString();
                    }
                });
                // year
      /*          final RadioGroup radioYear = findViewById(R.id.radio_year);
                radioYear.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, int checkedId) {
                        RadioButton rb = (RadioButton) findViewById(radioYear.getCheckedRadioButtonId());

                        String yearStr = rb.getText().toString();
                        if (!TextUtils.isEmpty(yearStr)){
                            year = Integer.valueOf(yearStr);
                        }
                    }
                });
*/
                //hide password
                if (!mbDisplayFlg) {
                    // display password text, for example "123456"
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    // hide password, display "."
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                mbDisplayFlg = !mbDisplayFlg;
                password.postInvalidate();


                }

        });


        List<String> list = new ArrayList<String>();
        list.add("2017");
        list.add("2018");
        list.add("2019");
        list.add("2020");
        list.add("other");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        Spinner sp = (Spinner) findViewById(R.id.Spinner01);
        sp.setAdapter(adapter);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            // parent： 为控件Spinner view：显示文字的TextView position：下拉选项的位置从0开始
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView tvResult = (TextView) findViewById(R.id.tv_year);
//获取Spinner控件的适配器
                ArrayAdapter<String> adapter = (ArrayAdapter<String>) parent.getAdapter();
                tvResult .setText(adapter.getItem(position));
            }
            //没有选中时的处理
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });



    }
}