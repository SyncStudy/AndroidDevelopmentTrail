package com.example.club.Database;

import com.example.club.Objects.User;

public interface RegisterDatabase {
    public User queryRegistered();
    public boolean insertUser();
    public boolean insertClub();
}
