package com.example.club.Service;

public interface LogInService {
    public String getResult(String username, String password);
}
